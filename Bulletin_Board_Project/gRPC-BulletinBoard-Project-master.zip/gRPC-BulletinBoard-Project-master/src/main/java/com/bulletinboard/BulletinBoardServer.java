package com.bulletinboard;

public class BulletinBoardServer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

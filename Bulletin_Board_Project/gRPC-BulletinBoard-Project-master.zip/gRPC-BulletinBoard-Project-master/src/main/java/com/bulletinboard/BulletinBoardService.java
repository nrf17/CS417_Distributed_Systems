package com.bulletinboard;

public class BulletinBoardService {

}
